package com.example.mainshoppingpage;

import static com.example.mainshoppingpage.R.layout.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.youth.banner.Banner;
import com.youth.banner.adapter.BannerImageAdapter;
import com.youth.banner.holder.BannerImageHolder;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_main);
        Banner banner = findViewById(R.id.banner_top);
        RecyclerView recyclerView = findViewById(R.id.rv_goods);
        initBottomTab();
        List<BannerClass> bannerList = new ArrayList<>();
        ArrayList<GoodsItem> goodsItems = new ArrayList<>();
        GridLayoutManager gridLayoutManager;
        for (int i = 0; i < 4; i++) {
            bannerList.add(new BannerClass(R.drawable.mall_banner2, "phone1"));
        }
        for (int i = 0; i < 11; i++) {
            goodsItems.add(new GoodsItem(R.drawable.img,i+"钛金手机","性能赛过苹果","128g 高级红","19999",100));
        }
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            gridLayoutManager = new GridLayoutManager(this,2);
        } else {
            gridLayoutManager = new GridLayoutManager(this,3);
        }
        RecyclerView.ItemDecoration itemDecoration = new MyItemDecoration();
        recyclerView.addItemDecoration(itemDecoration);
        recyclerView.setLayoutManager(gridLayoutManager);
        GoodsRvAdapter goodsRvAdapter = new GoodsRvAdapter(goodsItems);
        recyclerView.setAdapter(goodsRvAdapter);
        banner.setAdapter(new BannerImageAdapter<BannerClass>(bannerList) {
            @Override
            public void onBindView(BannerImageHolder holder, BannerClass data, int position, int size) {
                Glide.with(holder.imageView)
                        .load(data.getBannerImage())
                        .into(holder.imageView);
            }

        });

    }

    private void initBottomTab() {
        LinearLayout include1,include2,include3,include4;
        final TextView textView1,textView2,textView3,textView4;
        include1 = findViewById(R.id.bottom_tab_home);
        include2 = findViewById(R.id.bottom_tab_content);
        include3 = findViewById(R.id.bottom_tab_coupon);
        include4 = findViewById(R.id.bottom_tab_mine);
        include1.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this,MainActivity2.class);
            startActivity(intent);
        });
        include2.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this,MainActivity3.class);
            startActivity(intent);
        });
        textView1 = include1.findViewById(R.id.tv_get_goods);
        textView2 = include2.findViewById(R.id.tv_get_goods);
        textView3 = include3.findViewById(R.id.tv_get_goods);
        textView4 = include4.findViewById(R.id.tv_get_goods);
        ImageView imageView1,imageView2,imageView3,imageView4;
        imageView1 = include1.findViewById(R.id.iv_get_goods);
        imageView2 = include2.findViewById(R.id.iv_get_goods);
        imageView3 = include3.findViewById(R.id.iv_get_goods);
        imageView4 = include4.findViewById(R.id.iv_get_goods);
        Glide.with(this).load(R.mipmap.m1_menu_entrance).into(imageView1);
        Glide.with(this).load(R.mipmap.m1_menu_pick).into(imageView2);
        Glide.with(this).load(R.mipmap.m1_menu_sales_service).into(imageView3);
        Glide.with(this).load(R.mipmap.m1_menu_ticket).into(imageView4);
        textView1.setText(R.string.drink);
        textView2.setText(R.string.get_goods);
        textView3.setText(R.string.happy);
        textView4.setText(R.string.lottery);
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    static class BannerClass {

        private final int bannerImage;

        public final String imageName;

        public BannerClass(int bannerImage, String imageName) {
            this.bannerImage = bannerImage;
            this.imageName = imageName;
        }

        public int getBannerImage() {
            return bannerImage;
        }


    }

}