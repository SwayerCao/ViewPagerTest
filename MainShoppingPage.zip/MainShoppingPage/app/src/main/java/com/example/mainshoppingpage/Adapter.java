package com.example.mainshoppingpage;

public interface Adapter {
}
